class ItemModel {
  int? id;
  String name;
  String beschreibung;
  String ort;
  String anlageDatum;
  String? bildPfad;

  ItemModel({this.id, required this.name, required this.beschreibung, required this.ort, required this.anlageDatum, this.bildPfad});

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'beschreibung': beschreibung,
    'ort': ort,
    'anlageDatum': anlageDatum,
    'bildPfad': bildPfad,
  };

  factory ItemModel.fromMap(Map<String, dynamic> map) => ItemModel(
    id: map['id'],
    name: map['name'],
    beschreibung: map['beschreibung'],
    ort: map['ort'],
    anlageDatum: map['anlageDatum'],
    bildPfad: map['bildPfad'],
  );
}