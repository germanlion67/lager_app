import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/item_model.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();
  static Database? _db;

  Future<Database> get db async {
    if (_db != null) return _db!;
    _db = await initDb();
    return _db!;
  }

  Future<Database> initDb() async {
    String path = join(await getDatabasesPath(), 'lagerverwaltung.db');
    return await openDatabase(path, version: 1, onCreate: (Database db, int version) async {
      await db.execute('''
        CREATE TABLE items(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT,
          beschreibung TEXT,
          ort TEXT,
          anlageDatum TEXT,
          bildPfad TEXT
        )
      ''');
      await db.execute('''
        CREATE TABLE locations(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT
        )
      ''');
    });
  }

  Future<int> insertItem(ItemModel item) async {
    var client = await db;
    return client.insert('items', item.toMap());
  }

  Future<int> updateItem(ItemModel item) async {
    var client = await db;
    return client.update('items', item.toMap(), where: 'id=?', whereArgs: [item.id]);
  }

  Future<int> deleteItem(int id) async {
    var client = await db;
    return client.delete('items', where: 'id=?', whereArgs: [id]);
  }
}